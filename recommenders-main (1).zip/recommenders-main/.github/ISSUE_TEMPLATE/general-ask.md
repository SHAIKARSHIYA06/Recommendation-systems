---
name: General ask
about: Technical/non-technical asks about the repo
title: "[ASK] "
labels: 'help wanted'
assignees: ''

---

### Description
<!--- Describe your general ask in detail -->

### Willingness to contribute
<!--- Go over all the following points, and put an `x` in the box that apply. -->
- [ ] Yes, I can contribute for this issue independently.
- [ ] Yes, I can contribute for this issue with guidance from Recommenders community.
- [ ] No, I cannot contribute at this time.

### Other Comments
