# Copyright (c) Recommenders contributors.
# Licensed under the MIT License.

__title__ = "Recommenders"
__version__ = "1.2.0"
__author__ = "Recommenders contributors"
__license__ = "MIT"
__copyright__ = "Copyright 2018-present Recommenders contributors."

# Synonyms
TITLE = __title__
VERSION = __version__
AUTHOR = __author__
LICENSE = __license__
COPYRIGHT = __copyright__
